'use strict';
// ============================================================================
// test-suite-v2.js — Suite e re e testimit me skenarë realë të kërkuar nga përdoruesi
// Përdor logjikën REALE të aplikacionit:
//   - stock_movements ledger (type 'in'/'out', qty në njësinë bazë, enteredQty/unitMultiplier)
//   - computeQtyOnHand = sum of (in) - sum of (out) per product
//   - fbReceivePurchaseOrder logjika (me kontroll postimi të dyfishtë)
//   - fbCreateSale logjika (stock out per item, me free qty)
//   - fbCreateReturn logjika (stock in = rikthim stoku)
//   - warehouse isolation
//   - persistencë (close DB → reopen → verify)
//   - Fletë Hyrje / Fletë Dalje (warehouse_receipts_in / stock_movements type=out)
//   - backup & restore (copy file → wipe → restore → verify)
// ============================================================================

const fs = require('fs');
const path = require('path');
const os = require('os');

const { SistemiGenitDatabase, pushId } = require('./electron/database.js');

// --- helpers që pasqyrojnë logjikën reale të aplikacionit ---
function nowIso() { return new Date().toISOString(); }

// computeQtyOnHand — identik me funksionin në app.compiled.js (rreshti 2610)
function computeQtyOnHand(productId, movements) {
  return (movements || []).reduce(function(qty, m) {
    return m.productId === productId ? qty + (m.type === 'in' ? m.qty : -m.qty) : qty;
  }, 0);
}

// computeQtyOnHandByWarehouse — stoku për një magazinë specifike
function computeQtyOnHandByWarehouse(productId, warehouse, movements) {
  return (movements || []).reduce(function(qty, m) {
    if (m.productId !== productId) return qty;
    if (m.warehouse && m.warehouse !== warehouse) return qty;
    return qty + (m.type === 'in' ? m.qty : -m.qty);
  }, 0);
}

// Simulim i fbAddStockMovement (shton një lëvizje në ledger)
function addStockMovement(db, data, productName, userEmail) {
  const id = db.push('stock_movements', Object.assign({}, data, {
    performedBy: userEmail,
    createdAt: nowIso()
  }));
  return { success: true, id: id };
}

// Simulim i fbReceivePurchaseOrder (me kontroll postimi të dyfishtë — versioni i ri)
async function receivePurchaseOrder(db, po, user, warehouse, receiptMeta) {
  // Kontroll 1: statusi në objektin PO
  if (po && (po.status === 'received' || po.status === 'cancelled')) {
    return { success: false, message: 'Kjo porosi është marrë në stok tashmë (status: ' + po.status + '). Postim i dyfishtë nuk lejohet.' };
  }
  // Kontroll 2: lexo statusin aktual nga databaza (anti stale-click)
  if (po && po.id) {
    const cur = db.readValue('purchase_orders/' + po.id);
    if (cur && (cur.status === 'received' || cur.status === 'cancelled')) {
      return { success: false, message: 'Kjo porosi është marrë në stok tashmë (status: ' + cur.status + '). Postim i dyfishtë nuk lejohet.' };
    }
  }
  const targetWarehouse = warehouse || 'Magazina Kryesore';
  for (const it of (po.items || [])) {
    addStockMovement(db, {
      productId: it.productId,
      type: 'in',
      qty: Number(it.qty) || 0,
      enteredQty: Number(it.enteredQty != null ? it.enteredQty : it.qty) || 0,
      unitKey: it.unitKey || 'base',
      unitName: it.unitName || 'copë',
      unitMultiplier: Number(it.unitMultiplier) || 1,
      reason: 'Purchase',
      reference: po.poNumber,
      unitCost: Number(it.unitCost) || 0,
      supplier: po.supplierName || null,
      warehouse: targetWarehouse,
      notes: 'Marrje nga porosia e blerjes'
    }, it.name, user.email);
  }
  db.update('purchase_orders/' + po.id, {
    status: 'received',
    receivedAt: nowIso(),
    receivedWarehouse: targetWarehouse,
    warehouseReceiptId: receiptMeta && receiptMeta.id ? receiptMeta.id : null,
    warehouseReceiptNo: receiptMeta && receiptMeta.docNo ? receiptMeta.docNo : null
  });
  return { success: true, message: 'Porosia u mor në stok — gjendja u përditësua' };
}

// Simulim i fbCreateWarehouseReceiptIn (me kontroll postimi të dyfishtë)
async function createWarehouseReceiptIn(db, receipt, user) {
  if (receipt && receipt.poId) {
    const cur = db.readValue('purchase_orders/' + receipt.poId);
    if (cur && (cur.status === 'received' || cur.status === 'cancelled')) {
      return { success: false, message: 'Kjo porosi është marrë në stok tashmë (status: ' + cur.status + '). Fletë Hyrje e dyfishtë nuk lejohet.' };
    }
  }
  const id = db.push('warehouse_receipts_in', Object.assign({}, receipt, {
    createdAt: receipt.createdAt || nowIso(),
    createdBy: user.email,
    type: 'in'
  }));
  return { success: true, id: id, data: Object.assign({ id: id }, receipt), message: 'Fletë Hyrje u krijua' };
}

// Simulim i fbCreateSale (stock out per item, me free qty)
async function createSale(db, sale, user) {
  const saleId = db.push('sales', Object.assign({ status: 'completed' }, sale, {
    cashier: user.name,
    createdAt: nowIso()
  }));
  for (const it of sale.items) {
    addStockMovement(db, {
      productId: it.productId,
      type: 'out',
      qty: it.qty,
      enteredQty: Math.round(((Number(it.displayQty) || 0) + (Number(it.freeDisplayQty) || 0)) * 100) / 100,
      paidEnteredQty: it.displayQty || 0,
      freeEnteredQty: it.freeDisplayQty || 0,
      freeQty: it.freeQty || 0,
      unitKey: it.unitKey || 'base',
      unitName: it.unitName || null,
      unitMultiplier: it.unitMultiplier || 1,
      reason: 'Sale',
      reference: saleId,
      warehouse: it.warehouse || 'Magazina Kryesore'
    }, it.name, user);
  }
  return { success: true, id: saleId };
}

// Simulim i fbCreateReturn (rikthen stokun = type 'in', reason 'Return')
async function createReturn(db, saleId, items, user) {
  const returnId = db.push('returns', {
    saleId: saleId,
    items: items,
    processedBy: user.email,
    createdAt: nowIso()
  });
  for (const it of items) {
    addStockMovement(db, {
      productId: it.productId,
      type: 'in',
      qty: it.qty,
      reason: 'Return',
      reference: saleId,
      warehouse: it.warehouse || 'Magazina Kryesore'
    }, it.name, user);
  }
  return { success: true, id: returnId };
}

// Fletë Dalje = stock_movement me type 'out' + dokument
async function createFleteDalje(db, movement, user) {
  const id = db.push('warehouse_receipts_out', Object.assign({}, movement, {
    createdAt: nowIso(),
    createdBy: user.email,
    type: 'out'
  }));
  addStockMovement(db, {
    productId: movement.productId,
    type: 'out',
    qty: movement.qty,
    enteredQty: movement.enteredQty || movement.qty,
    unitName: movement.unitName || 'copë',
    unitMultiplier: movement.unitMultiplier || 1,
    reason: 'Fletë Dalje',
    reference: id,
    warehouse: movement.warehouse || 'Magazina Kryesore'
  }, movement.productName, user);
  return { success: true, id: id };
}

// Merr të gjitha lëvizjet e stokut si array
function getStockMovements(db) {
  const val = db.readValue('stock_movements') || {};
  return Object.entries(val).map(function(e) { return Object.assign({ id: e[0] }, e[1]); });
}

// Merr të gjitha Fletë Hyrje si array
function getFleteHyrje(db) {
  const val = db.readValue('warehouse_receipts_in') || {};
  return Object.entries(val).map(function(e) { return Object.assign({ id: e[0] }, e[1]); });
}

// Merr të gjitha Fletë Dalje si array
function getFleteDalje(db) {
  const val = db.readValue('warehouse_receipts_out') || {};
  return Object.entries(val).map(function(e) { return Object.assign({ id: e[0] }, e[1]); });
}

// ============================================================================
// SUITA E TESTIMIT — e gjithë brenda async IIFE për await të saktë
// ============================================================================

(async function() {

let passed = 0;
let failed = 0;
const results = [];

function test(name, fn) {
  const idx = results.length + 1;
  try {
    const r = fn();
    if (r === false) throw new Error('Assertion failed');
    passed++;
    results.push({ idx, name, status: 'PASS' });
    console.log('[PASS] B' + idx + ': ' + name);
  } catch (e) {
    failed++;
    results.push({ idx, name, status: 'FAIL', error: e.message });
    console.log('[FAIL] B' + idx + ': ' + name + ' — ' + e.message);
  }
}

async function testAsync(name, fn) {
  const idx = results.length + 1;
  try {
    await fn();
    passed++;
    results.push({ idx, name, status: 'PASS' });
    console.log('[PASS] B' + idx + ': ' + name);
  } catch (e) {
    failed++;
    results.push({ idx, name, status: 'FAIL', error: e.message });
    console.log('[FAIL] B' + idx + ': ' + name + ' — ' + e.message);
  }
}

// --- përgatitje databazë testi ---
const testDir = path.join(os.tmpdir(), 'sg-test-v2-' + Date.now());
fs.mkdirSync(testDir, { recursive: true });
const dbPath = path.join(testDir, 'sistemi_genit.db');
const backupPath = path.join(testDir, 'sistemi_genit_backup.db');

const user = { email: 'admin@test.al', name: 'Admin Test' };

let db = new SistemiGenitDatabase(dbPath);

// --- krijim produkt testi ---
const prodId = db.push('products', {
  name: 'Produkt Test Koli',
  sku: 'PTK-001',
  unit: 'copë',
  unit2Name: 'koli',
  unit2Coef: 12,
  cost: 100,
  price: 150,
  createdAt: nowIso()
});

const prodId2 = db.push('products', {
  name: 'Produkt Test Magazina',
  sku: 'PTM-002',
  unit: 'copë',
  cost: 50,
  price: 80,
  createdAt: nowIso()
});

console.log('\n========================================');
console.log('SUITA E TESTIMIT V2 — skenarë realë');
console.log('Databazë: ' + dbPath);
console.log('Data: ' + nowIso());
console.log('========================================\n');

// ============================================================================
// B1: 120 copë stok, 1 koli=12 copë, shitje 8 koli → mbeten 24 copë
// ============================================================================
test('B1: Stok 120 copë, shitje 8 koli×12=96, mbeten 24', function() {
  // Shto 120 copë në stok (hyrje fillestare)
  addStockMovement(db, {
    productId: prodId, type: 'in', qty: 120, enteredQty: 120,
    unitName: 'copë', unitMultiplier: 1, reason: 'Initial',
    warehouse: 'Magazina Kryesore'
  }, 'Produkt Test Koli', user.email);

  let movements = getStockMovements(db).filter(m => m.productId === prodId);
  let onHand = computeQtyOnHand(prodId, movements);
  if (onHand !== 120) throw new Error('Stok fillestar duhet 120, got ' + onHand);

  // Shitje 8 koli = 8 × 12 = 96 copë (qty në njësinë bazë = 96)
  // displayQty = 8 (koli), unitMultiplier = 12, qty = 96
  addStockMovement(db, {
    productId: prodId, type: 'out', qty: 96, enteredQty: 8,
    unitName: 'koli', unitMultiplier: 12, reason: 'Sale',
    warehouse: 'Magazina Kryesore'
  }, 'Produkt Test Koli', user.email);

  movements = getStockMovements(db).filter(m => m.productId === prodId);
  onHand = computeQtyOnHand(prodId, movements);
  if (onHand !== 24) throw new Error('Pas shitjes 8 koli (96 copë), stoku duhet 24, got ' + onHand);
  return true;
});

// ============================================================================
// B2: Sasia dhuratë (free) zbres stokun
// ============================================================================
test('B2: Sasia dhuratë (free) zbres stokun saktë', function() {
  // Produkt me stok 50 copë
  const fpId = db.push('products', { name: 'Produkt Falas', sku: 'PF-003', unit: 'copë', createdAt: nowIso() });
  addStockMovement(db, {
    productId: fpId, type: 'in', qty: 50, enteredQty: 50,
    unitName: 'copë', unitMultiplier: 1, reason: 'Initial',
    warehouse: 'Magazina Kryesore'
  }, 'Produkt Falas', user.email);

  // Shitje: 10 copë paguar + 5 copë falas = 15 copë total dalin nga stoku
  // Logjika e aplikacionit: qty = displayQty + freeDisplayQty = 10 + 5 = 15
  addStockMovement(db, {
    productId: fpId, type: 'out', qty: 15, enteredQty: 15,
    paidEnteredQty: 10, freeEnteredQty: 5, freeQty: 5,
    unitName: 'copë', unitMultiplier: 1, reason: 'Sale',
    warehouse: 'Magazina Kryesore'
  }, 'Produkt Falas', user.email);

  const movements = getStockMovements(db).filter(m => m.productId === fpId);
  const onHand = computeQtyOnHand(fpId, movements);
  if (onHand !== 35) throw new Error('Pas shitjes 10+5 falas (15 total), stoku duhet 35, got ' + onHand);
  return true;
});

// ============================================================================
// B3: Postim i dyfishtë i "Kalo në stok" bllokohet
// ============================================================================
await testAsync('B3: Postim i dyfishtë "Kalo në stok" bllokohet', async function() {
  // Krijo porosi blerjeje
  const poId = db.push('purchase_orders', {
    poNumber: 'PO-00001', status: 'ordered', supplierName: 'Furnitor Test',
    total: 1200, createdAt: nowIso(),
    items: [{ productId: prodId, name: 'Produkt Test Koli', qty: 48, enteredQty: 4, unitName: 'koli', unitMultiplier: 12, unitCost: 100, lineTotal: 400 }]
  });

  // Thirrja e parë: duhet të suksessojë
  const r1 = await receivePurchaseOrder(db, { id: poId, poNumber: 'PO-00001', status: 'ordered', supplierName: 'Furnitor Test', items: [{ productId: prodId, name: 'Produkt Test Koli', qty: 48, enteredQty: 4, unitName: 'koli', unitMultiplier: 12, unitCost: 100 }] }, user, 'Magazina Kryesore', { id: 'rec1', docNo: 'FH-00001' });
  if (!r1.success) throw new Error('Thirrja e parë duhet të suksesojë: ' + r1.message);

  // Verifiko stoku u shtua (+48)
  let movements = getStockMovements(db).filter(m => m.productId === prodId && m.reason === 'Purchase');
  let purchaseIn = movements.reduce((s, m) => s + m.qty, 0);
  if (purchaseIn !== 48) throw new Error('Pas marrjes së parë, hyrja Purchase duhet 48, got ' + purchaseIn);

  // Thirrja e dytë (postim i dyfishtë): duhet të refuzohet
  const r2 = await receivePurchaseOrder(db, { id: poId, poNumber: 'PO-00001', status: 'received', supplierName: 'Furnitor Test', items: [{ productId: prodId, name: 'Produkt Test Koli', qty: 48, enteredQty: 4, unitName: 'koli', unitMultiplier: 12, unitCost: 100 }] }, user, 'Magazina Kryesore', { id: 'rec2', docNo: 'FH-00002' });
  if (r2.success) throw new Error('Postimi i dyfishtë duhet të refuzohet, por u lejua!');

  // Verifiko stoku nuk u shtua përsëri (akoma 48, jo 96)
  movements = getStockMovements(db).filter(m => m.productId === prodId && m.reason === 'Purchase');
  purchaseIn = movements.reduce((s, m) => s + m.qty, 0);
  if (purchaseIn !== 48) throw new Error('Pas postimit të dyfishtë të refuzuar, hyrja Purchase duhet të jetë akoma 48, got ' + purchaseIn);

  // Thirrja e tretë me objekt PO stale (status 'ordered') por PO aktual në DB 'received'
  const r3 = await receivePurchaseOrder(db, { id: poId, poNumber: 'PO-00001', status: 'ordered', supplierName: 'Furnitor Test', items: [{ productId: prodId, name: 'Produkt Test Koli', qty: 48, enteredQty: 4, unitName: 'koli', unitMultiplier: 12, unitCost: 100 }] }, user, 'Magazina Kryesore', { id: 'rec3', docNo: 'FH-00003' });
  if (r3.success) throw new Error('Postimi i dyfishtë me PO stale duhet të refuzohet (lexim nga DB), por u lejua!');

  return true;
});

// ============================================================================
// B4: Fletë Hyrje e dyfishtë (createWarehouseReceiptIn) bllokohet
// ============================================================================
await testAsync('B4: Fletë Hyrje e dyfishtë bllokohet', async function() {
  const poId2 = db.push('purchase_orders', {
    poNumber: 'PO-00002', status: 'ordered', supplierName: 'Furnitor 2',
    total: 600, createdAt: nowIso(),
    items: [{ productId: prodId2, name: 'Produkt Test Magazina', qty: 20, enteredQty: 20, unitName: 'copë', unitMultiplier: 1, unitCost: 50, lineTotal: 1000 }]
  });

  // FH e parë: sukses
  const r1 = await createWarehouseReceiptIn(db, {
    docNo: 'FH-00002', poId: poId2, poNumber: 'PO-00002', supplierName: 'Furnitor 2',
    items: [{ productId: prodId2, qty: 20 }], total: 600, createdAt: nowIso()
  }, user);
  if (!r1.success) throw new Error('FH e parë duhet të suksesojë: ' + r1.message);

  // Marrja në stok
  await receivePurchaseOrder(db, { id: poId2, poNumber: 'PO-00002', status: 'ordered', supplierName: 'Furnitor 2', items: [{ productId: prodId2, qty: 20, unitName: 'copë', unitMultiplier: 1, unitCost: 50 }] }, user, 'Magazina Kryesore', { id: r1.id, docNo: 'FH-00002' });

  // FH e dytë: duhet refuzuar
  const r2 = await createWarehouseReceiptIn(db, {
    docNo: 'FH-00003', poId: poId2, poNumber: 'PO-00002', supplierName: 'Furnitor 2',
    items: [{ productId: prodId2, qty: 20 }], total: 600, createdAt: nowIso()
  }, user);
  if (r2.success) throw new Error('FH e dyfishtë duhet të refuzohet, por u krijua!');

  return true;
});

// ============================================================================
// B5: Anulim/editim i shitjes rikthen stokun (fbCreateReturn = type 'in')
// ============================================================================
test('B5: Anulim/rikthim i shitjes rikthen stokun (Return = type in)', function() {
  // Produkt me stok 100
  const rpId = db.push('products', { name: 'Produkt Rikthim', sku: 'PR-004', unit: 'copë', createdAt: nowIso() });
  addStockMovement(db, { productId: rpId, type: 'in', qty: 100, enteredQty: 100, unitName: 'copë', unitMultiplier: 1, reason: 'Initial', warehouse: 'Magazina Kryesore' }, 'Produkt Rikthim', user.email);

  // Shitje 30 copë
  const saleId = db.push('sales', { status: 'completed', total: 450, createdAt: nowIso(), items: [{ productId: rpId, qty: 30 }] });
  addStockMovement(db, { productId: rpId, type: 'out', qty: 30, enteredQty: 30, unitName: 'copë', unitMultiplier: 1, reason: 'Sale', reference: saleId, warehouse: 'Magazina Kryesore' }, 'Produkt Rikthim', user.email);

  let movements = getStockMovements(db).filter(m => m.productId === rpId);
  let onHand = computeQtyOnHand(rpId, movements);
  if (onHand !== 70) throw new Error('Pas shitjes 30, stoku duhet 70, got ' + onHand);

  // Rikthim (anulim) 30 copë = type 'in', reason 'Return'
  const items = [{ productId: rpId, qty: 30, name: 'Produkt Rikthim', lineTotal: 450, warehouse: 'Magazina Kryesore' }];
  addStockMovement(db, { productId: rpId, type: 'in', qty: 30, enteredQty: 30, unitName: 'copë', unitMultiplier: 1, reason: 'Return', reference: saleId, warehouse: 'Magazina Kryesore' }, 'Produkt Rikthim', user.email);

  movements = getStockMovements(db).filter(m => m.productId === rpId);
  onHand = computeQtyOnHand(rpId, movements);
  if (onHand !== 100) throw new Error('Pas rikthimit 30, stoku duhet rikthehet në 100, got ' + onHand);
  return true;
});

// ============================================================================
// B6: Magazinat e veçanta kanë stok të veçantë
// ============================================================================
test('B6: Magazinat e veçanta (Magazina Kryesore vs Depo 2) stok i veçantë', function() {
  const mpId = db.push('products', { name: 'Produkt Magazina', sku: 'PM-005', unit: 'copë', createdAt: nowIso() });

  // Hyrje 100 në Magazina Kryesore
  addStockMovement(db, { productId: mpId, type: 'in', qty: 100, enteredQty: 100, unitName: 'copë', unitMultiplier: 1, reason: 'Initial', warehouse: 'Magazina Kryesore' }, 'Produkt Magazina', user.email);
  // Hyrje 50 në Depo 2
  addStockMovement(db, { productId: mpId, type: 'in', qty: 50, enteredQty: 50, unitName: 'copë', unitMultiplier: 1, reason: 'Initial', warehouse: 'Depo 2' }, 'Produkt Magazina', user.email);

  // Shitje 30 nga Magazina Kryesore
  addStockMovement(db, { productId: mpId, type: 'out', qty: 30, enteredQty: 30, unitName: 'copë', unitMultiplier: 1, reason: 'Sale', warehouse: 'Magazina Kryesore' }, 'Produkt Magazina', user.email);

  const movements = getStockMovements(db).filter(m => m.productId === mpId);
  const onHandKryesore = computeQtyOnHandByWarehouse(mpId, 'Magazina Kryesore', movements);
  const onHandDepo2 = computeQtyOnHandByWarehouse(mpId, 'Depo 2', movements);
  const onHandTotal = computeQtyOnHand(mpId, movements);

  if (onHandKryesore !== 70) throw new Error('Magazina Kryesore duhet 70 (100-30), got ' + onHandKryesore);
  if (onHandDepo2 !== 50) throw new Error('Depo 2 duhet 50, got ' + onHandDepo2);
  if (onHandTotal !== 120) throw new Error('Total duhet 120, got ' + onHandTotal);
  return true;
});

// ============================================================================
// B7: Persistencë — mbyll databazën, ri-hap, verifiko të dhënat
// ============================================================================
test('B7: Persistencë SQLite (close → reopen → verify)', function() {
  // Shto të dhëna
  db.push('products', { name: 'Produkt Persistencë', sku: 'PP-006', unit: 'copë', createdAt: nowIso() });
  db.set('settings/config', { companyName: 'Test Co', currency: 'ALL' });

  // Mbyll dhe ri-hap
  db.close();
  db = new SistemiGenitDatabase(dbPath);

  // Verifiko të dhënat u ruajtën
  const products = db.readValue('products');
  if (!products || Object.keys(products).length < 6) throw new Error('Produktet nuk u ruajtën pas reopen, got ' + (products ? Object.keys(products).length : 0));

  const config = db.readValue('settings/config');
  if (!config || config.companyName !== 'Test Co') throw new Error('Settings nuk u ruajtën pas reopen');

  // Verifiko lëvizjet e stokut u ruajtën
  const movements = getStockMovements(db);
  if (movements.length < 10) throw new Error('Lëvizjet e stokut nuk u ruajtën pas reopen, got ' + movements.length);
  return true;
});

// ============================================================================
// B8: Fletë Hyrje dhe Fletë Dalje ruhen dhe rihapen
// ============================================================================
test('B8: Fletë Hyrje & Fletë Dalje ruhen & rihapen', function() {
  // Fletë Hyrje — ruhet në warehouse_receipts_in (si në aplikacion)
  const fhId = db.push('warehouse_receipts_in', {
    docNo: 'FH-TEST-001', supplierName: 'Furnitor FH', warehouse: 'Magazina Kryesore',
    items: [{ productId: prodId, name: 'Produkt Test', qty: 100, unitName: 'copë', unitMultiplier: 1, unitCost: 50, lineTotal: 5000 }],
    total: 5000, type: 'in', createdBy: user.email, createdAt: nowIso()
  });

  // Fletë Dalje — në aplikacionin real, FD = stock_movement type 'out' me reason
  // buildMovementWarehouseHtml(movement, product) e renderon nga movement
  const fdMovementId = addStockMovement(db, {
    productId: prodId, type: 'out', qty: 20, enteredQty: 20,
    unitName: 'copë', unitMultiplier: 1, reason: 'Fletë Dalje',
    reference: 'Klient Test', warehouse: 'Magazina Kryesore',
    performedBy: user.email, createdAt: nowIso()
  }, 'Produkt Test', user.email);

  // Lexo mbrapsht Fletë Hyrje
  const fhList = getFleteHyrje(db);
  const fh = fhList.find(f => f.id === fhId);
  if (!fh) throw new Error('Fletë Hyrje nuk u gjet pas ruajtjes');
  if (fh.docNo !== 'FH-TEST-001') throw new Error('FH docNo i pasaktë: ' + fh.docNo);
  if (!fh.items || fh.items.length !== 1) throw new Error('FH items mungojnë');

  // Lexo mbrapsht Fletë Dalje (nga stock_movements, type 'out', reason 'Fletë Dalje')
  const allMovements = getStockMovements(db);
  const fd = allMovements.find(m => m.id === fdMovementId.id);
  if (!fd) throw new Error('Fletë Dalje (movement) nuk u gjet pas ruajtjes');
  if (fd.type !== 'out') throw new Error('FD duhet type=out, got ' + fd.type);
  if (fd.reason !== 'Fletë Dalje') throw new Error('FD reason duhet "Fletë Dalje"');
  if (fd.reference !== 'Klient Test') throw new Error('FD reference duhet "Klient Test"');

  // Verifiko FD zbriti stokun
  const prodMovements = allMovements.filter(m => m.productId === prodId);
  const fdQty = prodMovements.filter(m => m.reason === 'Fletë Dalje').reduce((s, m) => s + m.qty, 0);
  if (fdQty !== 20) throw new Error('FD duhet të ketë zbritur 20 nga stoku, got ' + fdQty);
  return true;
});

// ============================================================================
// B9: Offline — 0 referenca CDN/eksterne në index.html
// ============================================================================
test('B9: Funksionim offline (0 CDN, 0 URL eksterne në index.html)', function() {
  const html = fs.readFileSync(path.join(__dirname, 'src', 'index.html'), 'utf8');
  const cdnMatches = html.match(/https?:\/\/(fonts\.googleapis|cdnjs|cdn\.|unpkg|jsdelivr|maxcdn|stackpath)/gi);
  if (cdnMatches && cdnMatches.length > 0) throw new Error('U gjetën ' + cdnMatches.length + ' referenca CDN: ' + cdnMatches.slice(0, 3).join(', '));

  const importMatches = html.match(/@import\s+url\(['"]?https?:/gi);
  if (importMatches && importMatches.length > 0) throw new Error('U gjetën ' + importMatches.length + ' @import eksterne');

  // Verifiko vendor files janë lokale
  const vendorRefs = html.match(/src="\.\.\/vendor\//g);
  if (!vendorRefs || vendorRefs.length < 10) throw new Error('Duhen të paktën 10 referenca vendor lokale, got ' + (vendorRefs ? vendorRefs.length : 0));
  return true;
});

// ============================================================================
// B10: Backup & restore (copy → wipe → restore → verify)
// ============================================================================
test('B10: Backup & restore (backup → fshih → restore → verifiko)', function() {
  // Shto të dhëna specifike për testin
  db.set('settings/backup_test', { marker: 'BACKUP_MARKER_' + Date.now(), value: 42 });

  // Backup
  db.backupTo(backupPath);
  if (!fs.existsSync(backupPath)) throw new Error('Backup file nuk u krijua');

  // Fshih të dhënat
  db.remove('settings/backup_test');
  db.remove('products');
  const afterRemove = db.readValue('settings/backup_test');
  if (afterRemove !== null) throw new Error('Të dhënat nuk u fshinë');

  // Restore: mbyll DB, kopjo backup mbi DB, ri-hap
  db.close();
  fs.copyFileSync(backupPath, dbPath);
  db = new SistemiGenitDatabase(dbPath);

  // Verifiko të dhënat u rikthyen
  const restored = db.readValue('settings/backup_test');
  if (!restored || restored.value !== 42) throw new Error('Të dhënat nuk u rikthyen pas restore');

  const products = db.readValue('products');
  if (!products || Object.keys(products).length < 5) throw new Error('Produktet nuk u rikthyen pas restore, got ' + (products ? Object.keys(products).length : 0));

  // Verifiko lëvizjet e stokut u rikthyen
  const movements = getStockMovements(db);
  if (movements.length < 10) throw new Error('Lëvizjet e stokut nuk u rikthyen pas restore, got ' + movements.length);
  return true;
});

// ============================================================================
// B11: XLSX real — exceljs prodhon OOXML ZIP
// ============================================================================
await testAsync('B11: XLSX real (exceljs prodhon PK ZIP/OOXML)', async function() {
  const ExcelJS = require('exceljs');
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Raport Test');
  ws.addRow(['Produkt', 'Njësia', 'Sasia', 'Çmimi', 'Total']);
  ws.addRow(['Produkt Test Koli', 'copë', 24, 150, 3600]);
  ws.addRow(['Produkt Falas', 'copë', 35, 80, 2800]);
  ws.addRow(['', '', '', 'TOTAL:', 6400]);

  const buf = await wb.xlsx.writeBuffer();
  const bufStr = buf.toString('latin1');
  if (bufStr.substring(0, 2) !== 'PK') throw new Error('XLSX duhet të fillojë me PK (ZIP), got ' + bufStr.substring(0, 2));

  const xlsxPath = path.join(testDir, 'test-raport-v2.xlsx');
  fs.writeFileSync(xlsxPath, buf);
  const stat = fs.statSync(xlsxPath);
  if (stat.size < 3000) throw new Error('XLSX shumë i vogël: ' + stat.size + ' bytes');

  // Verifiko është ZIP valid
  const { execSync } = require('child_process');
  try {
    execSync('unzip -t ' + xlsxPath, { stdio: 'pipe' });
  } catch (e) {
    throw new Error('XLSX nuk është ZIP valid: ' + e.message);
  }
  return true;
});

// ============================================================================
// B12: Query API (orderByChild / equalTo / limitToLast)
// ============================================================================
test('B12: Query API (orderByChild / equalTo / limitToLast)', function() {
  // Shto disa lëvizje me warehouse të ndryshëm
  const movements = getStockMovements(db);
  if (movements.length === 0) throw new Error('Nuk ka lëvizje për query test');

  // Query: orderByChild warehouse, equalTo 'Depo 2'
  const depo2 = db.query('stock_movements', { orderByChild: 'warehouse', equalTo: 'Depo 2' });
  if (!depo2) throw new Error('Query equalTo return null');
  const depo2Count = Object.keys(depo2).length;
  if (depo2Count === 0) throw new Error('Query equalTo Depo 2 duhet të ketë rezultate');

  // Query: limitToLast 3
  const last3 = db.query('stock_movements', { limitToLast: 3 });
  if (!last3 || Object.keys(last3).length !== 3) throw new Error('Query limitToLast 3 duhet të kthejë 3, got ' + (last3 ? Object.keys(last3).length : 0));
  return true;
});

// ============================================================================
// B13: Transaksione atomike (begin/commit/rollback)
// ============================================================================
test('B13: Transaksione atomike (rollback nuk e ruan ndryshimet)', function() {
  db.set('settings/atomic_test', { value: 'before' });
  const before = db.readValue('settings/atomic_test');
  if (!before || before.value !== 'before') throw new Error('Setup failed');

  db.begin();
  db.set('settings/atomic_test', { value: 'during' });
  const during = db.readValue('settings/atomic_test');
  if (!during || during.value !== 'during') throw new Error('Ndryshimi brenda transaksionit nuk u pa');
  db.rollback();

  const after = db.readValue('settings/atomic_test');
  if (!after || after.value !== 'before') throw new Error('Pas rollback, vlera duhet të jetë "before", got ' + (after ? after.value : 'null'));
  return true;
});

// ============================================================================
// B14: Fletë Hyrje me koli (8 koli × 12 = 96 copë në stok)
// ============================================================================
test('B14: Fletë Hyrje me koli (4 koli × 12 = 48 copë hyrje)', function() {
  const koliProductId = db.push('products', { name: 'Produkt Koli FH', sku: 'PKF-007', unit: 'copë', unit2Name: 'koli', unit2Coef: 12, createdAt: nowIso() });

  // Fletë Hyrje: 4 koli × 12 = 48 copë
  const receipt = {
    docNo: 'FH-KOLI-001', supplierName: 'Furnitor Koli', warehouse: 'Magazina Kryesore',
    items: [{ productId: koliProductId, name: 'Produkt Koli FH', qty: 48, enteredQty: 4, unitName: 'koli', unitMultiplier: 12, unitCost: 100, lineTotal: 4800 }],
    total: 4800, type: 'in', createdBy: user.email, createdAt: nowIso()
  };
  const fhId = db.push('warehouse_receipts_in', receipt);

  // Shto stok (type 'in', qty në bazë = 48)
  addStockMovement(db, {
    productId: koliProductId, type: 'in', qty: 48, enteredQty: 4,
    unitName: 'koli', unitMultiplier: 12, reason: 'Purchase',
    reference: 'FH-KOLI-001', warehouse: 'Magazina Kryesore'
  }, 'Produkt Koli FH', user.email);

  const movements = getStockMovements(db).filter(m => m.productId === koliProductId);
  const onHand = computeQtyOnHand(koliProductId, movements);
  if (onHand !== 48) throw new Error('Pas FH 4 koli, stoku duhet 48 copë, got ' + onHand);

  // Verifiko FH u ruajt
  const fh = getFleteHyrje(db).find(f => f.id === fhId);
  if (!fh || fh.items[0].enteredQty !== 4) throw new Error('FH nuk u ruajt saktë');
  return true;
});

// ============================================================================
// B15: Edito porosi blerjeje (update pa ndryshuar stokun)
// ============================================================================
test('B15: Editim porosie blerjeje (update pa prekur stokun)', function() {
  const epoId = db.push('purchase_orders', {
    poNumber: 'PO-EDIT-001', status: 'ordered', supplierName: 'Furnitor Origjinal',
    total: 500, createdAt: nowIso(),
    items: [{ productId: prodId, qty: 10, unitName: 'copë', unitMultiplier: 1, unitCost: 50, lineTotal: 500 }]
  });

  // Edito (update vetëm fushën supplierName)
  db.update('purchase_orders/' + epoId, { supplierName: 'Furnitor i Edituar', notes: 'Notë e re' });

  const updated = db.readValue('purchase_orders/' + epoId);
  if (!updated || updated.supplierName !== 'Furnitor i Edituar') throw new Error('Editimi i porosisë dështoi');
  if (updated.notes !== 'Notë e re') throw new Error('Notes nuk u përditësua');
  if (updated.status !== 'ordered') throw new Error('Statusi nuk duhet të ndryshojë nga editimi');
  if (!updated.items || updated.items.length !== 1) throw new Error('Items duhet të ruhen gjatë editimit');
  return true;
});

// ============================================================================
// PËRMLEDHJA
// ============================================================================
console.log('\n========================================');
console.log('PËRMLEDHJA: ' + passed + ' PASS / ' + failed + ' FAIL');
console.log('TOTAL: ' + results.length);
console.log('Data e testimit: ' + nowIso());
console.log('========================================');

if (failed > 0) {
  console.log('\nTESTET E DËSHTUARA:');
  results.filter(r => r.status === 'FAIL').forEach(r => console.log('  B' + r.idx + ': ' + r.name + ' — ' + r.error));
}

// Ruaj rezultatet në JSON
const reportPath = path.join(__dirname, 'test-output', 'test-results-v2.json');
fs.mkdirSync(path.dirname(reportPath), { recursive: true });
fs.writeFileSync(reportPath, JSON.stringify({
  testDate: nowIso(),
  total: results.length,
  passed: passed,
  failed: failed,
  results: results
}, null, 2));
console.log('\nRezultatet u ruajtën: ' + reportPath);

db.close();
process.exit(failed > 0 ? 1 : 0);

})(); // end async IIFE
