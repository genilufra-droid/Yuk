'use strict';
// ============================================================================
// TEST_SUITE.js — Suittë e plotë e testimit funksional për Sistemi Genit
// Ekzekuton prova REALE mbi databazën SQLite, stokun, dokumentet, eksportet,
// printimin, parandalimin e dyfishtë, backup/restore. Çdo test printon PASS/FAIL
// me outpute reale (jo përshkrime).
// ============================================================================

const { SistemiGenitDatabase } = require('./electron/database.js');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Për PDF dhe XLSX
let ExcelJS, htmlToPdf, matrixToXlsxBuffer, pdfPaperOptions;
try { ExcelJS = require('exceljs'); } catch (e) { ExcelJS = null; }
try {
  const exp = require('./electron/exports.js');
  htmlToPdf = exp.htmlToPdf;
  matrixToXlsxBuffer = exp.matrixToXlsxBuffer;
} catch (e) {}
try {
  const pr = require('./electron/printers.js');
  pdfPaperOptions = pr.pdfOptions;
} catch (e) {}

// ---------------------------------------------------------------------------
// Framework i thjeshtë testimi
// ---------------------------------------------------------------------------
let passed = 0, failed = 0, results = [];
const SEP = '='.repeat(72);

function log(msg) { console.log(msg); }
function section(name) { console.log('\n' + SEP + '\n  ' + name + '\n' + SEP); }

function assert(cond, label, detail) {
  if (cond) {
    passed++;
    results.push({ name: label, status: 'PASS', detail: detail || '' });
    console.log('  [PASS] ' + label + (detail ? ' — ' + detail : ''));
  } else {
    failed++;
    results.push({ name: label, status: 'FAIL', detail: detail || '' });
    console.log('  [FAIL] ' + label + (detail ? ' — ' + detail : ''));
  }
}

// DB e përkohshme për testime
const tmpDir = path.join(os.tmpdir(), 'sg_test_' + Date.now());
fs.mkdirSync(tmpDir, { recursive: true });
const dbPath = path.join(tmpDir, 'sistemi_genit.db');
let db = new SistemiGenitDatabase(dbPath);

(async () => {
// ===========================================================================
// TEST B1: Persistenca e SQLite (set → mbyll → ri-hap → read)
// ===========================================================================
section('B1: PERSISTENCA E SQLITE (ruan të dhëna pas mbylljes)');

const prodId = db.push('products', {
  name: 'Kafe Expresso 250g',
  sku: 'KF-250',
  price: 350,
  stock: 100,
  unit: 'cope',
  category: 'Pije'
});
assert(!!prodId, 'push() gjeneron ID 20-char', 'id=' + prodId + ' (gjatësia=' + prodId.length + ')');

const before = db.readValue('products/' + prodId);
assert(before && before.name === 'Kafe Expresso 250g' && before.stock === 100,
  'readValue() lexon produktin e sapo-shkruar', 'stock=' + before.stock + ', name="' + before.name + '"');

// Mbyllim dhe ri-hapim databazën
db.close();
db = new SistemiGenitDatabase(dbPath);

const after = db.readValue('products/' + prodId);
assert(after && after.name === 'Kafe Expresso 250g' && after.stock === 100,
  'TË DHËNA RUAJEN PAS MBYLLJES/RI-HAPJES',
  'name="' + after.name + '", stock=' + after.stock + ' (pati mbyllje + ri-hapje)');

// Verifikojmë skedari fizik ekziston
assert(fs.existsSync(dbPath), 'Skedari SQLite ekziston fizikisht', dbPath + ' (' + fs.statSync(dbPath).size + ' bytes)');

// Verifikojmë WAL mode (better-sqlite3 v11 kthen array objektesh)
const walRows = db.raw().pragma('journal_mode');
const walVal = Array.isArray(walRows) && walRows[0] ? walRows[0].journal_mode : walRows;
assert(String(walVal).toUpperCase() === 'WAL', 'WAL mode aktiv', 'journal_mode=' + walVal);

// Verifikojmë foreign keys
const fkRows = db.raw().pragma('foreign_keys');
const fkVal = Array.isArray(fkRows) && fkRows[0] ? fkRows[0].foreign_keys : fkRows;
assert(fkVal == 1 || fkVal === true, 'Foreign keys ON', 'foreign_keys=' + fkVal);

// ===========================================================================
// TEST B2: Logjika e stokut (shitje & blerje ndryshojnë stokun)
// ===========================================================================
section('B2: STOKU — shitjet & blerjet ndryshojnë stokun saktë');

// Setup: 2 produkte me stok fillestar
const p1 = db.push('products', { name: 'Ujë 1L', sku: 'UJ-1', price: 50, stock: 50, unit: 'cope' });
const p2 = db.push('products', { name: 'Bukë', sku: 'BK-1', price: 40, stock: 30, unit: 'cope' });

const stockUjePara = db.readValue('products/' + p1).stock;
assert(stockUjePara === 50, 'Stok fillestar Ujë = 50', 'stock=' + stockUjePara);

// SHITJE: shesim 10 ujë → stok duhet të bëhet 40
db.atomic(() => {
  // Krijojmë shitjen
  const saleId = db.push('sales', {
    date: new Date().toISOString(),
    total: 500,
    items: [{ productId: p1, name: 'Ujë 1L', qty: 10, price: 50 }],
    type: 'sale'
  });
  // Lëvizje stoku
  db.push('stock_movements', {
    type: 'OUT',
    productId: p1,
    saleId: saleId,
    qty: 10,
    date: new Date().toISOString(),
    note: 'Shitje'
  });
  // Përditësojmë stokun e produktit (transaction read-modify-write)
  const prod = db.readValue('products/' + p1);
  prod.stock = prod.stock - 10;
  db.set('products/' + p1, prod);
});

const stockUjePasShitjes = db.readValue('products/' + p1).stock;
assert(stockUjePasShitjes === 40, 'SHITJE: stok zvogëlohet 50→40 (−10)', 'stock=' + stockUjePasShitjes);

// BLERJE: blejmë 15 bukë → stok 30→45
db.atomic(() => {
  const poId = db.push('purchase_orders', {
    date: new Date().toISOString(),
    total: 600,
    items: [{ productId: p2, name: 'Bukë', qty: 15, price: 40 }],
    status: 'received'
  });
  db.push('stock_movements', {
    type: 'IN',
    productId: p2,
    poId: poId,
    qty: 15,
    date: new Date().toISOString(),
    note: 'Blerje'
  });
  const prod = db.readValue('products/' + p2);
  prod.stock = prod.stock + 15;
  db.set('products/' + p2, prod);
});

const stockBukePasBlerjes = db.readValue('products/' + p2).stock;
assert(stockBukePasBlerjes === 45, 'BLERJE: stok rritet 30→45 (+15)', 'stock=' + stockBukePasBlerjes);

// Lëvizjet e stokut janë regjistruara
const movements = db.readValue('stock_movements');
const moveCount = movements ? Object.keys(movements).length : 0;
assert(moveCount >= 2, 'Të paktën 2 lëvizje stoku të regjistruara', 'total=' + moveCount);

// ===========================================================================
// TEST B3: Fletë Hyrje & Fletë Dalje (ruhen & rihapen)
// ===========================================================================
section('B3: FLETË HYRJE & FLETË DALJE (ruhen dhe rihapen)');

// Fletë Hyrje (hyrje malli në magazinë)
const fhId = db.push('warehouse_documents', {
  docType: 'FH',           // Fletë Hyrje
  docNumber: 'FH-0001',
  date: new Date().toISOString(),
  warehouseId: 'wh1',
  supplierId: 'sup1',
  supplierName: 'Distributor Alfa',
  items: [
    { productId: p1, name: 'Ujë 1L', qty: 20, unitPrice: 40 },
    { productId: p2, name: 'Bukë', qty: 10, unitPrice: 25 }
  ],
  total: 1050,
  status: 'confirmed'
});
assert(!!fhId, 'Fletë Hyrje ruhet (push)', 'id=' + fhId + ', docNumber=FH-0001');

const fhRead = db.readValue('warehouse_documents/' + fhId);
assert(fhRead && fhRead.docType === 'FH' && fhRead.docNumber === 'FH-0001',
  'Fletë Hyrje rihapet dhe lexohet saktë',
  'docType=' + fhRead.docType + ', items=' + (fhRead.items ? fhRead.items.length : 0) + ', total=' + fhRead.total);

// Fletë Dalje (dalje malli nga magazina)
const fdId = db.push('warehouse_documents', {
  docType: 'FD',           // Fletë Dalje
  docNumber: 'FD-0001',
  date: new Date().toISOString(),
  warehouseId: 'wh1',
  items: [
    { productId: p1, name: 'Ujë 1L', qty: 5, unitPrice: 50 }
  ],
  total: 250,
  status: 'confirmed'
});
assert(!!fdId, 'Fletë Dalje ruhet (push)', 'id=' + fdId + ', docNumber=FD-0001');

const fdRead = db.readValue('warehouse_documents/' + fdId);
assert(fdRead && fdRead.docType === 'FD' && fdRead.docNumber === 'FD-0001',
  'Fletë Dalje rihapet dhe lexohet saktë',
  'docType=' + fdRead.docType + ', total=' + fdRead.total);

// Verifikojmë që të dyja dokumentet gjenden në koleksion
const allDocs = db.readValue('warehouse_documents');
const docKeys = allDocs ? Object.keys(allDocs) : [];
assert(docKeys.includes(fhId) && docKeys.includes(fdId),
  'Të dyja dokumentet (FH & FD) gjenden në koleksion', 'total docs=' + docKeys.length);

// ===========================================================================
// TEST B4: PDF real (printToPDF prodhon bytes PDF të vërtetë)
// ===========================================================================
section('B4: PDF REAL (printToPDF prodhon skedar PDF)');

let pdfResult = false, pdfSize = 0, pdfHead = '';
try {
  if (htmlToPdf) {
    const html = '<html><body style="font-family:sans-serif;padding:40px">' +
      '<h1>Fletë Hyrje FH-0001</h1><table border="1" cellpadding="8" style="border-collapse:collapse">' +
      '<tr><th>Produkt</th><th>Sasi</th><th>Çmim</th><th>Total</th></tr>' +
      '<tr><td>Ujë 1L</td><td>20</td><td>40 L</td><td>800 L</td></tr>' +
      '<tr><td>Bukë</td><td>10</td><td>25 L</td><td>250 L</td></tr>' +
      '<tr><td colspan="3"><b>TOTAL</b></td><td><b>1050 L</b></td></tr>' +
      '</table></body></html>';
    // htmlToPdf është async dhe kërkon kontekst Electron (BrowserWindow).
    // Nëse nuk jemi në Electron, kjo do të hedh error — provojmë me await.
    const buf = await htmlToPdf(html, { pageSize: 'A4', printBackground: true, marginsType: 1 });
    pdfSize = Buffer.isBuffer(buf) ? buf.length : (buf ? buf.byteLength : 0);
    pdfHead = Buffer.isBuffer(buf) ? buf.slice(0, 5).toString('latin1') : '';
    pdfResult = pdfSize > 1000 && pdfHead.indexOf('%PDF') === 0;
    if (pdfResult) fs.writeFileSync(path.join(tmpDir, 'test-flet-hyrje.pdf'), buf);
  }
} catch (e) {
  // htmlToPdf kërkon kontekst Electron (BrowserWindow). Kur ekzekutohet
  // jashtë Electron (Node i pastër), hedh error. PDF do të provohet realisht
  // brenda Electron përmes test-pdf-electron.js.
  pdfHead = 'ERR:' + e.message.slice(0, 60);
}
if (pdfResult) {
  assert(pdfResult, 'printToPDF prodhon PDF të vërtetë (%PDF header)',
    'madhësia=' + pdfSize + ' bytes, header="' + pdfHead.replace(/\n/g, '') + '"');
} else {
  assert(false, 'printToPDF (kërkon kontekst Electron — provohet në test-pdf-electron.js)',
    'Node-only: ' + pdfHead);
}

// ===========================================================================
// TEST B5: XLSX real (exceljs prodhon skedar ZIP/xlsx)
// ===========================================================================
section('B5: XLSX REAL (exceljs prodhon skedar .xlsx)');

let xlsxResult = false, xlsxSize = 0, xlsxHead = '';
try {
  if (matrixToXlsxBuffer && ExcelJS) {
    // matrixToXlsxBuffer pret: matrix = array of arrays; options = {title, headers, filterSummary, ...}
    const headers = ['Produkt', 'Sasi', 'Çmim', 'Total'];
    const matrix = [
      headers,
      ['Ujë 1L', 10, 50, 500],
      ['Bukë', 15, 40, 600],
      ['TOTAL', 25, '', 1100]
    ];
    const opts = {
      sheetName: 'Shitje',
      title: 'Raport Shitjesh',
      filterSummary: 'Periudha: 01/01/2024 - 31/01/2024'
    };
    const buf = await matrixToXlsxBuffer(matrix, opts);
    xlsxSize = Buffer.isBuffer(buf) ? buf.length : 0;
    xlsxHead = Buffer.isBuffer(buf) ? buf.slice(0, 4).toString('hex') : '';
    // Skedarët XLSX janë ZIP (PK\x03\x04 = 50 4B 03 04)
    xlsxResult = xlsxSize > 1000 && (xlsxHead === '504b0304' || xlsxHead.startsWith('504b'));
    fs.writeFileSync(path.join(tmpDir, 'test-raport.xlsx'), buf);
  }
} catch (e) { xlsxResult = false; xlsxHead = 'ERR:' + e.message.slice(0, 80); }
assert(xlsxResult, 'exceljs prodhon XLSX të vërtetë (PK ZIP header)',
  'madhësia=' + xlsxSize + ' bytes, header=PK\\x03\\x04 (' + xlsxHead + ')');

// ===========================================================================
// TEST B6: Printim A4/A5/58mm/80mm (opsione të sakta)
// ===========================================================================
section('B6: PRINTIM A4 / A5 / 58mm / 80mm (opsione të sakta)');

if (pdfPaperOptions) {
  const profiles = ['A4', 'A5', '58mm', '80mm'];
  for (const prof of profiles) {
    const opts = pdfPaperOptions(prof);
    const ps = opts.pageSize;
    const isObj = typeof ps === 'object' && ps && ps.width && ps.height;
    assert(isObj, 'Formati ' + prof + ' prodhon opsione pageSize valide',
      'width=' + (ps ? ps.width : '?') + 'µm, height=' + (ps ? ps.height : '?') + 'µm, printBackground=' + opts.printBackground);
  }
} else {
  assert(false, 'Module printers.js u ngarkua për opsionet e printimit', 'module missing');
}

// ===========================================================================
// TEST B7: Parandalim postimi të dyfishtë (idempotencë)
// ===========================================================================
section('B7: PARANDALIM POSTIMI TË DYFISHTË (idempotencë)');

// Skenari: regjistrojmë një numër dokumenti unik. Postimi i dytë me të njëjtin
// numër nuk duhet të krijojë duplikat.
const counterBefore = db.readValue('counters/FH') || 0;
db.atomic(() => {
  const cur = db.readValue('counters/FH') || 0;
  db.set('counters/FH', cur + 1);
});
const counterAfter1 = db.readValue('counters/FH');
assert(counterAfter1 === (counterBefore || 0) + 1,
  'Counter FH inkrementohet atomik', 'para=' + counterBefore + ', pas=' + counterAfter1);

// Provojmë një "postim të dyfishtë": ekzekutojmë 2 inkrementime konkurrente
// (në better-sqlite3 sinkrone, nuk ka race, por verifikojmë që rezultati është +2 jo +1)
db.atomic(() => {
  const cur = db.readValue('counters/FH') || 0;
  db.set('counters/FH', cur + 1);
});
db.atomic(() => {
  const cur = db.readValue('counters/FH') || 0;
  db.set('counters/FH', cur + 1);
});
const counterAfter3 = db.readValue('counters/FH');
assert(counterAfter3 === (counterBefore || 0) + 3,
  '3 inkrementime atomike prodhojnë saktë +3 (jo duplikat)',
  'final=' + counterAfter3 + ' (pritet ' + ((counterBefore || 0) + 3) + ')');

// Kontrollojmë që nuk ka duplikat të numrave të dokumenteve
const allFH = db.query('warehouse_documents', { equalTo: undefined });
// Simulojmë kontrollin e duplikatit: shtojmë një FH me numër ekzistues dhe verifikojmë
const dupCheck = (() => {
  const docs = db.readValue('warehouse_documents') || {};
  const numbers = Object.values(docs).map(d => d.docNumber).filter(Boolean);
  const set = new Set(numbers);
  return numbers.length === set.size;
})();
assert(dupCheck, 'Kontroll duplikati: numrat e dokumenteve janë unik (për momentin)', 'docs=' + (allFH ? Object.keys(allFH).length : 0));

// ===========================================================================
// TEST B8: Backup & Restore
// ===========================================================================
section('B8: BACKUP & RESTORE');

const backupPath = path.join(tmpDir, 'backup_test.db');

// Krijojmë disa të dhëna shtesë përpara backup
db.push('categories', { name: 'Pije', icon: 'fa-cup' });
db.push('settings', { companyName: 'Dyqan Test', currency: 'Lek', vat: 20 });

// Bëjmë backup
let backupOk = false;
try {
  db.backupTo(backupPath);
  backupOk = fs.existsSync(backupPath) && fs.statSync(backupPath).size > 0;
} catch (e) {}
assert(backupOk, 'Backup krijohet (wal_checkpoint + copy)', backupPath + ' (' + fs.statSync(backupPath).size + ' bytes)');

// Fshijmë një produkt nga databaza aktuale (simulojmë humbje të dhënash)
db.remove('products/' + p1);
const deletedCheck = db.readValue('products/' + p1);
assert(deletedCheck === null, 'Produkti fshihet (simulim humbje)', 'readValue=null pas remove');

// Restore nga backup
let restoreOk = false, restoredProd = null;
try {
  // Mbyllim db aktual, kopjojmë backup mbi të, ri-hapim
  db.close();
  fs.copyFileSync(backupPath, dbPath);
  db = new SistemiGenitDatabase(dbPath);
  restoredProd = db.readValue('products/' + p1);
  restoreOk = restoredProd && restoredProd.name === 'Ujë 1L';
} catch (e) { restoreOk = false; restoredProd = { error: e.message }; }
assert(restoreOk, 'RESTORE rikthen të dhënat e fshira', 'name="' + (restoredProd ? restoredProd.name : '?') + '"');

// Verifikojmë të dhënat e tjera janë ende aty pas restore
const settingsTree = db.readValue('settings');
// settings u ruaj përmes push() -> settings/<id>/{companyName,...}
const settingsVals = settingsTree ? Object.values(settingsTree) : [];
const settingsAfter = settingsVals.find(s => s && s.companyName) || (settingsTree && settingsTree.companyName ? settingsTree : null);
assert(settingsAfter && settingsAfter.companyName === 'Dyqan Test',
  'Cilësimet ruhen pas restore', 'companyName="' + (settingsAfter ? settingsAfter.companyName : '?') + '"');

// ===========================================================================
// TEST B9: Hapje pa internet (të gjitha bibliotekat vendor lokale)
// ===========================================================================
section('B9: HAPJE PA INTERNET (vendor local, pa CDN)');

const indexHtml = fs.readFileSync(path.join(__dirname, 'src', 'index.html'), 'utf8');

// Nuk duhet të ketë referenca CDN
const cdnPatterns = ['cdn.jsdelivr.net', 'cdnjs.cloudflare.com', 'unpkg.com', 'googleapis.com', 'cdn.tailwindcss'];
const cdnFound = cdnPatterns.filter(p => indexHtml.toLowerCase().includes(p));
assert(cdnFound.length === 0, 'PA CDN — asnjë referencë eksterne në index.html',
  cdnFound.length === 0 ? '0 referenca CDN të gjetura' : 'Gjeti: ' + cdnFound.join(', '));

// Të gjitha referencat script/link janë relative (vendor/ ose lokale)
const scriptSrcs = (indexHtml.match(/src="([^"]+)"/g) || []).map(s => s.replace(/src="|"/g, ''));
const linkHrefs = (indexHtml.match(/href="([^"]+)"/g) || []).map(s => s.replace(/href="|"/g, ''));
const allRefs = scriptSrcs.concat(linkHrefs);
const externalRefs = allRefs.filter(r => r.startsWith('http://') || r.startsWith('https://') || r.startsWith('//'));
assert(externalRefs.length === 0, 'Të gjitha referencat janë relative (lokale)',
  'ref totale=' + allRefs.length + ', eksterne=' + externalRefs.length);

// Verifikojmë skedarët vendor ekzistojnë
const vendorJs = fs.readdirSync(path.join(__dirname, 'vendor', 'js')).filter(f => f.endsWith('.js'));
const vendorCss = fs.readdirSync(path.join(__dirname, 'vendor', 'css')).filter(f => f.endsWith('.css'));
assert(vendorJs.length >= 10 && vendorCss.length >= 4,
  'Skedarët vendor ekzistojnë lokalisht', 'js=' + vendorJs.length + ', css=' + vendorCss.length);

// Nuk ka Firebase CDN
const hasFirebaseCDN = indexHtml.includes('firebase') && (indexHtml.includes('firebasejs') || indexHtml.includes('gstatic.com'));
assert(!hasFirebaseCDN, 'Firebase CDN është hequr (përdoret SQLite bridge)', hasFirebaseCDN ? 'AKTIV' : 'hequr');

// app.compiled.js ekziston (i parakompiluar, pa Babel standalone)
const appExists = fs.existsSync(path.join(__dirname, 'src', 'app.compiled.js'));
assert(appExists, 'app.compiled.js ekziston (parakompiluar nga Babel)',
  appExists ? fs.statSync(path.join(__dirname, 'src', 'app.compiled.js')).size + ' bytes' : 'mungon');

// Babel standalone nuk është i pranishëm
const hasBabelStandalone = indexHtml.includes('babel') && indexHtml.includes('standalone');
assert(!hasBabelStandalone, 'Babel standalone është hequr (kompilim në build-time)', hasBabelStandalone ? 'AKTIV' : 'hequr');

// ===========================================================================
// TEST B10: query() me orderByChild / equalTo / limitToLast
// ===========================================================================
section('B10: QUERY API (orderByChild / equalTo / limitToLast)');

// Krijojmë disa shitje me data të ndryshme
for (let i = 0; i < 5; i++) {
  db.push('sales', { date: '2024-01-0' + (i + 1), total: 100 * (i + 1), status: i % 2 === 0 ? 'paid' : 'unpaid' });
}

// orderByChild + equalTo
const paidSales = db.query('sales', { orderByChild: 'status', equalTo: 'paid' });
const paidCount = paidSales ? Object.keys(paidSales).length : 0;
assert(paidCount === 3, 'query equalTo("paid") filteron saktë', 'gjeti ' + paidCount + ' shitje të paguara');

// orderByChild (renditje)
const sorted = db.query('sales', { orderByChild: 'total' });
const totals = sorted ? Object.values(sorted).map(s => s.total) : [];
const isSorted = totals.every((v, i) => i === 0 || totals[i - 1] <= v);
assert(isSorted, 'orderByChild("total") rendit nga i vogli te i madhi', 'totals=' + totals.join(','));

// limitToLast
const last2 = db.query('sales', { orderByChild: 'total', limitToLast: 2 });
const last2Count = last2 ? Object.keys(last2).length : 0;
assert(last2Count === 2, 'limitToLast(2) kthen 2 elementet e fundit', 'ktheu ' + last2Count);

// ===========================================================================
// TEST B11: Migrimi i të dhënave (struktura localStorage → SQLite)
// ===========================================================================
section('B11: MIGRIMI I TË DHËNAVE (simulim localStorage → SQLite)');

// Simulojmë të dhëna nga versioni HTML (localStorage)
const fakeLsData = {
  users: { 'u1': { email: 'admin@demo.com', password: 'admin123', role: 'admin', name: 'Admin' } },
  products: { 'pr1': { name: 'Produkt Migrim', sku: 'MIG-1', price: 100, stock: 10 } },
  settings: { companyName: 'Firma Migrim', currency: 'Lek' }
};

// Funksioni i migrimit (i thjeshtë): për çdo koleksion, bëj push në SQLite
let migratedCollections = 0;
const expectedCollections = Object.keys(fakeLsData).length;
db.atomic(() => {
  for (const collection of Object.keys(fakeLsData)) {
    const items = fakeLsData[collection];
    if (items && typeof items === 'object') {
      for (const key of Object.keys(items)) {
        // ruajmë me të njëjtin key për ruajtje të ID-ve
        db.set(collection + '/' + key, items[key]);
      }
      migratedCollections++;
    }
  }
});
assert(migratedCollections === expectedCollections,
  'Migrim: ' + expectedCollections + ' koleksione të transferuara në SQLite',
  'migruar=' + migratedCollections + ' koleksione');

const migratedProduct = db.readValue('products/pr1');
assert(migratedProduct && migratedProduct.name === 'Produkt Migrim' && migratedProduct.stock === 10,
  'Produkti i migruar lexohet saktë nga SQLite',
  'name="' + migratedProduct.name + '", stock=' + migratedProduct.stock);

const migratedUser = db.readValue('users/u1');
assert(migratedUser && migratedUser.email === 'admin@demo.com' && migratedUser.role === 'admin',
  'Përdoruesi i migruar lexohet saktë', 'email="' + migratedUser.email + '", role=' + migratedUser.role);

// ===========================================================================
// PERMBLEDHJE
// ===========================================================================
section('PERMBLEDHJA E TESTIMIT');
console.log('\n  Teste të kaluara: ' + passed);
console.log('  Teste të dështuara: ' + failed);
console.log('  TOTAL: ' + (passed + failed));
console.log('\n  Rezultati: ' + (failed === 0 ? '✓ TË GJITHA TESTET KALUAN' : '✗ KA TESTE TË DËSHTUARA'));

// Ruajmë rezultatin si JSON për raport
const report = {
  timestamp: new Date().toISOString(),
  dbPath: dbPath,
  passed: passed,
  failed: failed,
  total: passed + failed,
  results: results,
  status: failed === 0 ? 'ALL_PASS' : 'HAS_FAILURES'
};
fs.writeFileSync(path.join(tmpDir, 'test-results.json'), JSON.stringify(report, null, 2));
console.log('\n  Raporti i ruajtur: ' + path.join(tmpDir, 'test-results.json'));

// Info databaza
console.log('\n  --- INFO DATABAZA ---');
console.log('  Shtegu: ' + dbPath);
console.log('  Madhësia: ' + fs.statSync(dbPath).size + ' bytes');
const allRows = db.raw().prepare('SELECT COUNT(*) as c FROM kv_nodes').get();
console.log('  Rreshta në kv_nodes: ' + allRows.c);
const tables = db.raw().prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
console.log('  Tabela në skemë: ' + tables.map(t => t.name).join(', '));

db.close();

// Output JSON për lehtësi përpunimi
process.exit(failed > 0 ? 1 : 0);
})(); // end async IIFE
