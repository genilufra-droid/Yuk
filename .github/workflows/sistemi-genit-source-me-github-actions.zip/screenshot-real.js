'use strict';
// ============================================================================
// screenshot-real.js — Hap aplikacionin REAL Electron, merr screenshot-a
// 1. Login screen
// 2. Pas login-it (dashboard)
// Krijon një përdorues demo në databazë përpara në mënyrë që login të funksionojë
// ============================================================================

const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

const { SistemiGenitDatabase } = require('./electron/database.js');

let mainWindow = null;
const screenshotDir = path.join(__dirname, 'test-output', 'screenshots');
if (!fs.existsSync(screenshotDir)) fs.mkdirSync(screenshotDir, { recursive: true });

// --- krijimi i përdoruesit demo përpara ---
const userDataDir = app.getPath('userData');
const dbDir = path.join(userDataDir, 'data');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
const dbPath = path.join(dbDir, 'sistemi_genit.db');
const db = new SistemiGenitDatabase(dbPath);

// Krijimi i përdoruesit admin demo (nëse nuk ekziston)
const existingUsers = db.readValue('users') || {};
const hasAdmin = Object.values(existingUsers).some(u => u.email === 'admin@genit.al');
if (!hasAdmin) {
  db.push('users', {
    name: 'Admin Demo',
    email: 'admin@genit.al',
    password: 'admin123',
    role: 'Admin',
    active: true,
    createdAt: new Date().toISOString()
  });
  console.log('[SETUP] Përdoruesi demo admin@genit.al u krijua');
}

// Krijimi i settings (nëse mungojnë)
const settings = db.readValue('settings');
if (!settings || Object.keys(settings).length === 0) {
  db.push('settings', {
    companyName: 'Sistemi Genit Demo',
    currency: 'ALL',
    taxRate: 0,
    invoicePrefix: 'INV-',
    warehouses: ['Magazina Kryesore', 'Depo 2'],
    createdAt: new Date().toISOString()
  });
  console.log('[SETUP] Settings u krijuan');
}

db.close();

// --- krijimi i dritares ---
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    webPreferences: {
      preload: path.join(__dirname, 'electron', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  mainWindow.webContents.on('did-finish-load', async () => {
    console.log('[EVENT] Faqja u ngarkua, pres 2s për render...');

    // Screenshot 1: Login screen
    await new Promise(r => setTimeout(r, 2500));
    try {
      const img = await mainWindow.webContents.capturePage();
      const fpath = path.join(screenshotDir, '01-login-screen.png');
      fs.writeFileSync(fpath, img.toPNG());
      console.log('[SCREENSHOT] 01-login-screen.png (' + img.getSize().width + 'x' + img.getSize().height + ')');
    } catch (e) {
      console.log('[ERROR] Screenshot 1: ' + e.message);
    }

    // Përpjekja për login përmes JavaScript injection
    console.log('[ACTION] Po mundohem të bëj login...');
    try {
      // Plotëso fushat e email dhe password përmes JS
      await mainWindow.webContents.executeJavaScript(`
        (function() {
          // Gjej fushat e input
          var inputs = document.querySelectorAll('input');
          var emailInput = null, passInput = null;
          for (var i = 0; i < inputs.length; i++) {
            var inp = inputs[i];
            if (inp.type === 'email' || inp.type === 'text' && (inp.placeholder || '').toLowerCase().indexOf('email') >= 0 || inp.name === 'email') {
              emailInput = inp;
            }
            if (inp.type === 'password') {
              passInput = inp;
            }
          }
          if (emailInput && passInput) {
            var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            nativeInputValueSetter.call(emailInput, 'admin@genit.al');
            emailInput.dispatchEvent(new Event('input', { bubbles: true }));
            nativeInputValueSetter.call(passInput, 'admin123');
            passInput.dispatchEvent(new Event('input', { bubbles: true }));
            return 'fields-filled';
          }
          // fallback: prov me React state
          return 'fields-not-found: ' + inputs.length + ' inputs';
        })();
      `).then(result => {
        console.log('[LOGIN] ' + result);
      });
    } catch (e) {
      console.log('[LOGIN ERROR] ' + e.message);
    }

    await new Promise(r => setTimeout(r, 1000));

    // Kliko butonin Hyr
    try {
      await mainWindow.webContents.executeJavaScript(`
        (function() {
          var buttons = document.querySelectorAll('button');
          for (var i = 0; i < buttons.length; i++) {
            var txt = (buttons[i].textContent || '').trim();
            if (txt === 'Hyr' || txt.toLowerCase() === 'login' || txt.toLowerCase().indexOf('hyr') >= 0) {
              buttons[i].click();
              return 'clicked: ' + txt;
            }
          }
          return 'no-button-found: ' + buttons.length + ' buttons';
        })();
      `).then(result => {
        console.log('[LOGIN BUTTON] ' + result);
      });
    } catch (e) {
      console.log('[LOGIN BUTTON ERROR] ' + e.message);
    }

    // Screenshot 2: Pas login (dashboard)
    await new Promise(r => setTimeout(r, 4000));
    try {
      const img2 = await mainWindow.webContents.capturePage();
      const fpath2 = path.join(screenshotDir, '02-after-login.png');
      fs.writeFileSync(fpath2, img2.toPNG());
      console.log('[SCREENSHOT] 02-after-login.png (' + img2.getSize().width + 'x' + img2.getSize().height + ')');
    } catch (e) {
      console.log('[ERROR] Screenshot 2: ' + e.message);
    }

    // Merr tekstin e faqes për të verifikuar çfarë u shfaq
    try {
      const pageText = await mainWindow.webContents.executeJavaScript('document.body ? document.body.innerText.substring(0, 500) : "no body"');
      console.log('[PAGE TEXT] ' + pageText.substring(0, 300));
    } catch (e) {
      console.log('[TEXT ERROR] ' + e.message);
    }

    console.log('[DONE] Të gjitha screenshot-at u morën');
    app.quit();
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  console.log('[START] Electron app ready, duke hapur dritaren...');
  createWindow();
});

app.on('window-all-closed', () => {
  app.quit();
});

// Timeout safety
setTimeout(() => {
  console.log('[TIMEOUT] 30s timeout, dalje...');
  app.quit();
}, 30000);
