// Screenshot test: launch app, capture page, save PNG, exit
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');

// Initialize the database module so SQLite is ready
let db;
try {
  const { SistemiGenitDatabase } = require('./electron/database.js');
  const dbPath = path.join(app.getPath('userData'), 'sistemi_genit.db');
  db = new SistemiGenitDatabase(dbPath);
  console.log('[SCREENSHOT-TEST] Database ready at:', dbPath);
} catch (e) {
  console.error('[SCREENSHOT-TEST] DB init error:', e.message);
}

// Register minimal IPC handlers so the renderer can communicate
ipcMain.handle('sqlite:once', (e, p, q) => {
  try { return { success: true, value: db.query(p, q) }; }
  catch (err) { return { success: true, value: null, message: err.message }; }
});
ipcMain.handle('sqlite:set', (e, p, v) => {
  try { db.set(p, v); return { success: true }; }
  catch (err) { return { success: false, message: err.message }; }
});
ipcMain.handle('sqlite:update', (e, p, v) => {
  try { db.update(p, v); return { success: true }; }
  catch (err) { return { success: false, message: err.message }; }
});
ipcMain.handle('sqlite:remove', (e, p) => {
  try { db.remove(p); return { success: true }; }
  catch (err) { return { success: false, message: err.message }; }
});
ipcMain.handle('sqlite:push', (e, p, v) => {
  try { const key = db.push(p, v); return { success: true, key }; }
  catch (err) { return { success: false, message: err.message }; }
});
ipcMain.handle('sqlite:logActivity', (e, d) => {
  try { db.logActivity(d || {}); return { success: true }; }
  catch (err) { return { success: false, message: err.message }; }
});
ipcMain.handle('app:info', () => ({ app: { version: '1.0.0' }, platform: process.platform }));
ipcMain.handle('printer:list', async () => []);
ipcMain.handle('dialog:save', async () => ({ canceled: true }));
ipcMain.handle('dialog:open', async () => ({ canceled: true }));

const screenshots = [
  path.join(__dirname, 'screenshot-login.png'),
];

let win;
let captureCount = 0;
let pollCount = 0;
const MAX_POLLS = 30; // 30 * 1s = 30s max

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'electron', 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    show: false,
  });

  win.loadFile(path.join(__dirname, 'src', 'index.html'));

  win.webContents.on('console-message', (e, level, msg, line, source) => {
    const tag = ['LOG', 'WARN', 'ERR'][level] || 'LOG';
    console.log(`[CONSOLE:${tag}] ${msg}`);
  });

  // Poll and capture screenshots at intervals to catch different render states
  const pollInterval = setInterval(async () => {
    pollCount++;
    if (pollCount === 6 || pollCount === 12 || pollCount === MAX_POLLS) {
      try {
        const img = await win.webContents.capturePage();
        const filePath = screenshots[captureCount] || path.join(__dirname, `screenshot-${captureCount}.png`);
        fs.writeFileSync(filePath, img.toPNG());
        console.log(`[SCREENSHOT-TEST] Saved screenshot #${captureCount} to ${filePath} (${img.getSize().width}x${img.getSize().height})`);
        captureCount++;
      } catch (e) {
        console.error('[SCREENSHOT-TEST] Capture error:', e.message);
      }
    }
    if (pollCount >= MAX_POLLS) {
      clearInterval(pollInterval);
      app.quit();
    }
  }, 1000);

  // Also quit on crash
  win.webContents.on('render-process-gone', (e, details) => {
    console.error('[SCREENSHOT-TEST] Render process gone:', details.reason);
    clearInterval(pollInterval);
    app.quit();
  });
});

app.on('window-all-closed', () => {
  console.log('[SCREENSHOT-TEST] All windows closed, exiting.');
  app.quit();
});

// Safety timeout - force quit after 40s no matter what
setTimeout(() => {
  console.log('[SCREENSHOT-TEST] Force timeout, exiting.');
  app.quit();
  process.exit(0);
}, 40000);
