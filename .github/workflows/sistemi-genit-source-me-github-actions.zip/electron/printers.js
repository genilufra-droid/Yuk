'use strict';
// ============================================================================
// printers.js
// Windows printer integration for Sistemi Genit using Electron APIs.
//
// Provides:
//   - list printers installed on Windows (webContents.getPrintersAsync())
//   - print HTML content to a specific printer with options
//   - printToPDF with page size (A4, A5, 58mm, 80mm) and orientation
//   - remember printer preferences per document type in settings
//   - save PDF/XLSX via native dialogs (handled in main.js)
// ============================================================================

// Paper size presets (in microns = 1/1000 mm) used by Electron printToPDF.
// Electron uses microns for 'pageSize' when given as an object.
const PAPER_PRESETS = {
  'A4': { width: 210000, height: 297000 },
  'A5': { width: 148000, height: 210000 },
  // 58 mm thermal receipt: 58mm wide; height is continuous -> use a tall page
  '58mm': { width: 58000, height: 297000 },
  '80mm': { width: 80000, height: 297000 },
  'letter': { width: 215900, height: 279400 }
};

// margins in points (1/72 inch). 0 = no margins (thermal).
const DEFAULT_MARGINS = {
  marginType: 0,            // 0 = default, 1 = none, 2 = custom (in points)
  margins: { top: 0, bottom: 0, left: 0, right: 0 }
};

function paperSizeFor(format) {
  const f = String(format || 'A4').trim();
  const key = Object.keys(PAPER_PRESETS).find(k => k.toLowerCase() === f.toLowerCase());
  return key ? PAPER_PRESETS[key] : PAPER_PRESETS.A4;
}

// Build printToPDF options from a print profile.
// profile: { format: 'A4'|'A5'|'58mm'|'80mm', landscape: bool, margins, printBackground }
function pdfOptions(profile) {
  profile = profile || {};
  const pageSize = profile.pageSize || paperSizeFor(profile.format);
  const opts = {
    pageSize,
    printBackground: profile.printBackground !== false,
    landscape: !!profile.landscape,
    preferCSSPageSize: !!profile.preferCSSPageSize
  };
  if (profile.margins) {
    opts.margins = profile.margins; // {top,bottom,left,right} in points
  }
  return opts;
}

// Print options passed to webContents.print()
function printOptions(profile, printerName) {
  profile = profile || {};
  const opts = {
    silent: !!profile.silent,
    printBackground: profile.printBackground !== false,
    color: profile.color !== false,
    copies: Math.max(1, parseInt(profile.copies, 10) || 1)
  };
  if (printerName) opts.deviceName = printerName;
  if (profile.landscape) opts.landscape = true;
  if (profile.pageSize) opts.pageSize = profile.pageSize;
  if (profile.margins) opts.margins = profile.margins;
  return opts;
}

module.exports = {
  PAPER_PRESETS,
  paperSizeFor,
  pdfOptions,
  printOptions
};
